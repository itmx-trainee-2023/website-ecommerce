import Blog1 from "../../../public/img/Blog1.png"
import Blog2 from "../../../public/img/Blog2.png";
import Blog3 from "../../../public/img/Blog3.png";
import Blog4 from "../../../public/img/Blog4.png";
import Blog5 from "../../../public/img/Blog5.png";
import Blog6 from "../../../public/img/Blog6.png";
import Blog7 from "../../../public/img/Blog7.png";
import Blog8 from "../../../public/img/Blog8.png";
import Blog9 from "../../../public/img/Blog9.png";

export const blog = 
[
  {
    "name": "7 ways to decor your home like a professional",
    "description": "October 16, 2023",
    "img" : Blog1
  },
  {
    "name": "Inside a beautiful kitchen organization",
    "description": "October 16, 2023",
    "img" : Blog2
  },
  {
    "name": "Decor your bedroom for your children",
    "description": "October 16, 2023",
    "img" : Blog3
  },
  {
    "name": "Modern texas home is beautiful and completely kid-friendly",
    "description": "October 16, 2023",
    "img" : Blog4
  },
  {
    "name": "Modern texas home is beautiful and completely kid-friendly",
    "description": "October 16, 2023",
    "img" : Blog5
  },
  {
    "name": "Modern texas home is beautiful and completely kid-friendly",
    "description": "October 16, 2023",
    "img" : Blog6
  },
  {
    "name": "Modern texas home is beautiful and completely kid-friendly",
    "description": "October 16, 2023",
    "img" : Blog7
  },
  {
    "name": "Modern texas home is beautiful and completely kid-friendly",
    "description": "October 16, 2023",
    "img" : Blog8
  },
  {
    "name": "Modern texas home is beautiful and completely kid-friendly",
    "description": "October 16, 2023",
    "img" : Blog9
  }
]
