import card1 from "../../../public/img/Card1.png";
import card2 from "../../../public/img/Card2.png";
import card3 from "../../../public/img/Card3.png";
import card4 from "../../../public/img/Card4.png";
import card5 from "../../../public/img/Card5.png";
import card6 from "../../../public/img/Card6.png";
import card7 from "../../../public/img/Card7.png";
import card8 from "../../../public/img/Card8.png";
import card9 from "../../../public/img/Card9.png";

export const shops = [
  {
    name: "Loveseat Sofa",
    price: 199.0,
    img: card1,
  },
  {
    name: "Luxury Sofa",
    price: 299.0,
    img: card2,
  },
  {
    name: "Table lamp",
    price: 19.0,
    img: card3,
  },
  {
    name: "White Drawer unit",
    price: 89.99,
    img: card4,
  },
  {
    name: "Black Tray table",
    price: 19.99,
    img: card5,
  },
  {
    name: "Lamp",
    price: 39.0,
    img: card6,
  },
  {
    name: "Light Beige Pillow",
    price: 3.99,
    img: card7,
  },
  {
    name: "Table Lamp",
    price: 39.99,
    img: card8,
  },
  {
    name: "Bamboo Basket",
    price: 9.99,
    img: card9,
  },
];
